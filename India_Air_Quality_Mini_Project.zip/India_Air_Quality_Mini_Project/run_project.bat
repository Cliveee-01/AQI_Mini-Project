@echo off
setlocal
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (
    set "PYTHON_CMD=.venv\Scripts\python.exe"
    set "STREAMLIT_CMD=.venv\Scripts\streamlit.exe"
) else (
    set "PYTHON_CMD=python"
    set "STREAMLIT_CMD=streamlit"
)
echo ================================================
echo India Air Quality - Experiment 10 Mini Project
echo ================================================
"%PYTHON_CMD%" train_models.py
if errorlevel 1 goto error
"%PYTHON_CMD%" generate_report.py
if errorlevel 1 goto error
"%STREAMLIT_CMD%" run app.py
if errorlevel 1 goto error
goto end
:error
echo.
echo A command failed. Check the message above and confirm requirements are installed.
pause
:end
endlocal
