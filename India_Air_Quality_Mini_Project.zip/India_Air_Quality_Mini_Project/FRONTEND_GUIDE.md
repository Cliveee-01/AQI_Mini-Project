# AeroIQ frontend guide

The project frontend is built with **Streamlit**, so the same Python project contains the user interface and the analysis backend.

## Pages / tabs

- **Overview:** headline metrics, monthly AQI, seasonal comparison, highest-AQI cities, category distribution, and correlation insights.
- **City & seasonal trends:** city multi-select for monthly comparisons, year-on-year line chart, pollutant-correlation heatmap, and ranked correlation table.
- **Model lab:** regression metrics (R², RMSE, MAE), error comparison, actual-vs-predicted chart, Random Forest feature importance, classification accuracy, per-category scores, and confusion matrix.
- **Predict AQI:** editable pollutant inputs populated with dataset medians; returns a numeric AQI estimate plus a category from the separate classifier.
- **Data & method:** data-quality counters, cleaning method, cleaned-data preview, and CSV/JSON downloads.

## Run the frontend

From the project folder, open PowerShell or a terminal and run:

```bash
python -m pip install -r requirements.txt
streamlit run app.py
```

Streamlit will print a local URL (usually `http://localhost:8501`). Open it in a browser. On Windows, `run_project.bat` can train the models, regenerate the report and launch the UI in one sequence.

## Dataset

The frontend starts with `data/city_day_demo_synthetic.csv` when no official file is found. This is clearly marked as **demo mode**. For final report results, upload the official Kaggle `city_day.csv` using the sidebar uploader or save it as `data/city_day.csv` and restart the app.

## Notes

- The app runs the training/evaluation pipeline for a new uploaded CSV and caches a processed dataset during the Streamlit session.
- AQI prediction is an educational estimate from fitted models, not an official live CPCB value.
- Model scores are held-out random-split metrics. They should not be interpreted as a reliable future forecast without a time-based evaluation.
