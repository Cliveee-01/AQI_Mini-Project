"""Run EDA and train/evaluate baseline AQI prediction models."""
from pathlib import Path
import json
import pandas as pd
from aqi_pipeline import run_analysis

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
OUTPUT_DIR = ROOT / "outputs"
OFFICIAL = DATA_DIR / "city_day.csv"
DEMO = DATA_DIR / "city_day_demo_synthetic.csv"

if OFFICIAL.exists():
    data_path = OFFICIAL
    print(f"Using official/local dataset: {data_path}")
else:
    data_path = DEMO
    print("NOTICE: data/city_day.csv was not found. Using synthetic DEMO data instead.")
    print("Download the Kaggle city_day.csv before using results in your final report.")
raw = pd.read_csv(data_path)
result = run_analysis(raw, OUTPUT_DIR, save_models=True)
summary = result["summary"]
summary["dataset_file"] = data_path.name
summary["is_synthetic_demo"] = data_path.name == DEMO.name
with open(OUTPUT_DIR / "results_summary.json", "w", encoding="utf-8") as f:
    json.dump(summary, f, indent=2, ensure_ascii=False)
print("\n--- DATA CLEANING ---")
print(json.dumps(summary["cleaning"], indent=2))
print("\n--- REGRESSION METRICS ---")
print(result["regression_metrics"].to_string(index=False, float_format=lambda x: f"{x:.4f}"))
print("\n--- CLASSIFICATION ACCURACY ---")
acc = summary["classification"]["accuracy"]
print(f"{acc:.4f}" if acc is not None else "Not available (insufficient labeled rows)")
print("\n--- TOP CITIES BY AVERAGE AQI ---")
for item in summary["top_cities_by_aqi"]:
    print(f"{item['City']}: {item['AQI']:.2f}")
print("\n--- STRONGEST ABSOLUTE CORRELATIONS WITH AQI ---")
for item in summary["strongest_abs_correlations"]:
    print(f"{item['feature']}: {item['correlation']:.3f}")
print(f"\nFiles saved in {OUTPUT_DIR}")
