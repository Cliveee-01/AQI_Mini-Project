from pathlib import Path
from io import BytesIO
import hashlib
import json

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import streamlit as st
from aqi_pipeline import run_analysis, POLLUTANT_FEATURES, AQI_BUCKET_ORDER, SEASON_ORDER, MONTH_NAMES

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
OUTPUT_DIR = ROOT / "outputs"
OFFICIAL = DATA_DIR / "city_day.csv"
DEMO = DATA_DIR / "city_day_demo_synthetic.csv"

# ------------------------------- App setup ----------------------------------
st.set_page_config(
    page_title="AeroIQ | India Air Quality",
    page_icon="🌫️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# AQI palette is also used by charts and prediction cards.
AQI_COLORS = {
    "Good": "#16A34A",
    "Satisfactory": "#65A30D",
    "Moderate": "#D97706",
    "Poor": "#EA580C",
    "Very Poor": "#DC2626",
    "Severe": "#7F1D1D",
}
NAVY = "#101D33"
TEAL = "#0E9F9A"
BLUE = "#4568F5"
POLLUTANT_LABELS = {
    "PM2.5": "Fine particles (PM2.5)",
    "PM10": "Coarse particles (PM10)",
    "NO": "Nitric oxide (NO)",
    "NO2": "Nitrogen dioxide (NO₂)",
    "NOx": "Nitrogen oxides (NOx)",
    "NH3": "Ammonia (NH₃)",
    "CO": "Carbon monoxide (CO)",
    "SO2": "Sulphur dioxide (SO₂)",
    "O3": "Ozone (O₃)",
    "Benzene": "Benzene",
    "Toluene": "Toluene",
    "Xylene": "Xylene",
}

st.markdown(
    """
    <style>
      @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@400;500;600;700;800&display=swap');
      :root { --ink:#152238; --muted:#718096; --line:#E4EAF2; --paper:#F5F8FC; --teal:#0E9F9A; }
      html, body, [class*="css"] { font-family: 'DM Sans', sans-serif; }
      .stApp { background: #F5F8FC; color: var(--ink); }
      [data-testid="stHeader"] { background: rgba(245,248,252,.88); }
      [data-testid="stToolbar"] { right: 1rem; }
      .block-container { padding-top: 1.6rem; padding-bottom: 3rem; max-width: 1500px; }
      [data-testid="stSidebar"] { background: #101D33; border-right: 1px solid rgba(255,255,255,.08); }
      [data-testid="stSidebar"] * { color: #E8EEF8; }
      [data-testid="stSidebar"] [data-testid="stFileUploaderDropzone"] { background: #1A2A45; border: 1px dashed #49617F; }
      [data-testid="stSidebar"] [data-testid="stFileUploaderDropzone"] button { color: #142238; }
      [data-testid="stSidebar"] a { color: #75E1D5 !important; }
      [data-testid="stSidebar"] hr { border-color: #34445D; }
      [data-testid="stSidebar"] [data-testid="stSelectbox"] > div > div,
      [data-testid="stSidebar"] [data-testid="stMultiSelect"] > div > div { background:#1A2A45; border-color:#354863; }
      h1, h2, h3, h4 { font-family:'Manrope', sans-serif !important; color:#152238; letter-spacing:-.035em; }
      h2 { font-size:1.35rem !important; margin-bottom:.2rem !important; }
      h3 { font-size:1.05rem !important; letter-spacing:-.02em; }
      p, li { color:#526178; }
      [data-testid="stMetric"] { background:#FFFFFF; border:1px solid #E4EAF2; border-radius:17px; padding:17px 19px; box-shadow:0 6px 18px rgba(16,29,51,.035); }
      [data-testid="stMetricLabel"] { color:#718096 !important; font-weight:600; font-size:.78rem !important; }
      [data-testid="stMetricValue"] { color:#152238 !important; font-family:'Manrope',sans-serif; font-weight:800; }
      [data-testid="stTabs"] [data-baseweb="tab-list"] { gap:8px; background:#EAF0F7; border-radius:14px; padding:6px; }
      [data-testid="stTabs"] button[role="tab"] { border-radius:10px; padding:10px 14px; color:#58677D; font-weight:700; }
      [data-testid="stTabs"] button[role="tab"][aria-selected="true"] { background:white; color:#152238; box-shadow:0 2px 7px rgba(16,29,51,.08); }
      [data-testid="stVerticalBlockBorderWrapper"] { border-radius:18px; border-color:#E4EAF2; background:white; }
      [data-testid="stDataFrame"] { border:1px solid #E4EAF2; border-radius:12px; overflow:hidden; }
      .hero { position:relative; overflow:hidden; border-radius:25px; padding:29px 32px 28px; color:white; background:linear-gradient(115deg,#101D33 0%,#163657 55%,#087E83 100%); box-shadow:0 16px 34px rgba(19,52,78,.14); margin-bottom:20px; }
      .hero:after { content:''; position:absolute; width:330px; height:330px; border-radius:50%; right:-50px; top:-155px; border:1px solid rgba(255,255,255,.12); box-shadow:0 0 0 30px rgba(255,255,255,.035),0 0 0 70px rgba(255,255,255,.025); }
      .hero-kicker { font-size:.72rem; letter-spacing:.17em; text-transform:uppercase; font-weight:800; color:#7CE3D9; margin-bottom:10px; }
      .hero-title { font-family:'Manrope',sans-serif; font-size:clamp(1.8rem,3vw,2.55rem); line-height:1.13; font-weight:800; letter-spacing:-.055em; color:white; margin:0; }
      .hero-copy { max-width:680px; color:#D2DFEC; font-size:.94rem; margin-top:12px; line-height:1.6; }
      .hero-chip { display:inline-flex; align-items:center; gap:8px; background:rgba(255,255,255,.1); border:1px solid rgba(255,255,255,.18); padding:8px 11px; border-radius:999px; font-size:.72rem; letter-spacing:.02em; color:#F4FBFF; margin-top:18px; }
      .hero-dot { width:7px; height:7px; border-radius:50%; background:#69E7B7; display:inline-block; }
      .section-eyebrow { color:#0E8C89; font-size:.7rem; font-weight:800; letter-spacing:.14em; text-transform:uppercase; margin-bottom:5px; }
      .section-title { color:#152238; font-family:'Manrope',sans-serif; font-size:1.36rem; font-weight:800; letter-spacing:-.04em; margin:0 0 3px; }
      .section-subtitle { color:#7A879A; font-size:.83rem; margin-bottom:14px; }
      .panel-title { color:#152238; font-family:'Manrope',sans-serif; font-size:1rem; font-weight:800; letter-spacing:-.025em; margin-bottom:2px; }
      .panel-note { font-size:.76rem; color:#8190A4; margin-bottom:12px; }
      .insight-card { background:#FFFFFF; border:1px solid #E4EAF2; border-radius:18px; padding:19px 20px; height:100%; box-shadow:0 6px 18px rgba(16,29,51,.025); }
      .insight-label { color:#8391A4; font-size:.72rem; font-weight:800; letter-spacing:.09em; text-transform:uppercase; }
      .insight-value { color:#152238; font-family:'Manrope',sans-serif; font-weight:800; font-size:1.42rem; letter-spacing:-.04em; margin-top:5px; }
      .insight-sub { color:#718096; font-size:.78rem; margin-top:3px; }
      .status-note { border-radius:13px; border:1px solid #F6D48B; background:#FFF8E8; color:#805A10; padding:12px 15px; font-size:.82rem; margin:10px 0 17px; }
      .success-note { border-radius:13px; border:1px solid #B5E4D1; background:#ECFDF5; color:#16654D; padding:12px 15px; font-size:.82rem; margin:10px 0 17px; }
      .prediction-card { border-radius:22px; padding:24px; color:white; background:linear-gradient(130deg,#101D33,#244B67); }
      .prediction-label { color:#C1D4E5; font-weight:700; font-size:.76rem; letter-spacing:.08em; text-transform:uppercase; }
      .prediction-number { font-family:'Manrope',sans-serif; font-size:3.2rem; font-weight:800; letter-spacing:-.065em; color:#FFFFFF; line-height:1.05; margin:12px 0 5px; }
      .prediction-muted { color:#C1D4E5; font-size:.83rem; }
      .category-pill { display:inline-block; border-radius:999px; padding:6px 11px; color:#fff; font-weight:800; font-size:.78rem; }
      .small-muted { color:#8190A4; font-size:.75rem; }
      .side-brand { display:flex; gap:10px; align-items:center; padding:10px 3px 20px; }
      .side-brand-mark { display:flex; align-items:center; justify-content:center; height:42px; width:42px; border-radius:13px; color:white; background:linear-gradient(140deg,#13B8AD,#4568F5); font-size:23px; box-shadow:0 8px 20px rgba(14,159,154,.2); }
      .side-brand-name { color:#F5F8FC; font-family:'Manrope',sans-serif; font-size:1.15rem; font-weight:800; letter-spacing:-.04em; }
      .side-brand-sub { color:#8FA2BD; font-size:.7rem; margin-top:1px; }
      .side-label { color:#8FA2BD; font-size:.67rem; font-weight:800; letter-spacing:.13em; text-transform:uppercase; margin:9px 0 7px; }
      div.stButton > button[kind="primary"], div.stFormSubmitButton > button[kind="primary"] { background:linear-gradient(105deg,#0E9F9A,#137FC1); border:0; color:white; font-weight:800; border-radius:11px; min-height:45px; box-shadow:0 7px 18px rgba(14,159,154,.18); }
      div.stButton > button, div.stDownloadButton > button { border-radius:11px; font-weight:700; }
      div[data-testid="stForm"] { background:#FFFFFF; padding:18px 20px 8px; border:1px solid #E4EAF2; border-radius:18px; }
      .footer { color:#97A3B5; font-size:.72rem; text-align:center; padding:22px 0 5px; }
      @media (max-width: 750px) { .hero { padding:23px 22px; border-radius:19px; } .hero-title { font-size:1.8rem; } .block-container { padding-left:1rem; padding-right:1rem; } }
    </style>
    """,
    unsafe_allow_html=True,
)


def aqi_category(value: float) -> str:
    if value <= 50:
        return "Good"
    if value <= 100:
        return "Satisfactory"
    if value <= 200:
        return "Moderate"
    if value <= 300:
        return "Poor"
    if value <= 400:
        return "Very Poor"
    return "Severe"


def aqi_color(value: float) -> str:
    return AQI_COLORS[aqi_category(value)]


def section_heading(eyebrow: str, title: str, subtitle: str = ""):
    st.markdown(
        f'<div class="section-eyebrow">{eyebrow}</div><div class="section-title">{title}</div><div class="section-subtitle">{subtitle}</div>',
        unsafe_allow_html=True,
    )


def panel_heading(title: str, note: str = ""):
    st.markdown(f'<div class="panel-title">{title}</div><div class="panel-note">{note}</div>', unsafe_allow_html=True)


def base_figure(figsize=(8, 4.3)):
    fig, ax = plt.subplots(figsize=figsize, facecolor="white")
    ax.set_facecolor("white")
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    for side in ("bottom", "left"):
        ax.spines[side].set_color("#E4EAF2")
    ax.tick_params(colors="#68788D", labelsize=9)
    ax.grid(axis="y", color="#EAF0F6", linewidth=.8)
    ax.set_axisbelow(True)
    return fig, ax


def chart_monthly(frame: pd.DataFrame):
    means = frame.groupby("Month")["AQI"].mean().reindex(range(1, 13))
    fig, ax = base_figure((8.5, 3.7))
    x = np.arange(1, 13)
    y = means.to_numpy(dtype=float)
    ax.plot(x, y, color=TEAL, linewidth=2.7, marker="o", markersize=5.5, markerfacecolor="white", markeredgewidth=2)
    ax.fill_between(x, y, 0, color=TEAL, alpha=.08)
    ax.set_xticks(x, MONTH_NAMES)
    ax.set_ylabel("Average AQI", color="#68788D", fontsize=9)
    ax.set_title("Monthly pollution pattern", loc="left", fontsize=12, fontweight="bold", color=NAVY, pad=13)
    ax.grid(axis="x", visible=False)
    return fig


def chart_seasonal(frame: pd.DataFrame):
    grouped = frame.groupby("Season")["AQI"].mean().reindex(SEASON_ORDER).dropna()
    fig, ax = base_figure((7.5, 3.7))
    vals = grouped.values
    colors = [aqi_color(v) for v in vals]
    bars = ax.bar(grouped.index.astype(str), vals, color=colors, width=.56, edgecolor="none")
    for bar, val in zip(bars, vals):
        ax.text(bar.get_x() + bar.get_width()/2, val + max(vals)*.025, f"{val:.0f}", ha="center", va="bottom", fontsize=9, fontweight="bold", color=NAVY)
    ax.set_ylim(0, max(vals)*1.18 if len(vals) else 1)
    ax.set_title("Average AQI by season", loc="left", fontsize=12, fontweight="bold", color=NAVY, pad=13)
    ax.grid(axis="x", visible=False)
    return fig


def chart_city_rankings(frame: pd.DataFrame, top_n: int = 9):
    grouped = frame.groupby("City", as_index=False)["AQI"].mean().sort_values("AQI", ascending=False).head(top_n).sort_values("AQI")
    fig, ax = base_figure((8.5, 4.2))
    vals = grouped["AQI"].to_numpy()
    bars = ax.barh(grouped["City"], vals, color=[aqi_color(v) for v in vals], height=.63)
    for bar, val in zip(bars, vals):
        ax.text(val + max(vals)*.015, bar.get_y()+bar.get_height()/2, f"{val:.0f}", va="center", fontsize=8.5, color=NAVY, fontweight="bold")
    ax.set_xlim(0, max(vals)*1.16 if len(vals) else 1)
    ax.set_xlabel("Average AQI", fontsize=9, color="#68788D")
    ax.set_title("Cities with the highest average AQI", loc="left", fontsize=12, fontweight="bold", color=NAVY, pad=13)
    ax.grid(axis="x", color="#EAF0F6")
    ax.grid(axis="y", visible=False)
    return fig, grouped.sort_values("AQI", ascending=False)


def chart_yearly(frame: pd.DataFrame):
    means = frame.groupby("Year")["AQI"].mean().sort_index()
    fig, ax = base_figure((8.5, 3.7))
    ax.plot(means.index.astype(int), means.values, color=BLUE, linewidth=2.7, marker="o", markersize=6)
    for x, y in zip(means.index, means.values):
        ax.annotate(f"{y:.0f}", (x, y), textcoords="offset points", xytext=(0, 8), ha="center", fontsize=8, color=NAVY)
    ax.set_xticks(means.index.astype(int))
    ax.set_ylabel("Average AQI", fontsize=9, color="#68788D")
    ax.set_title("Year-on-year AQI", loc="left", fontsize=12, fontweight="bold", color=NAVY, pad=13)
    ax.grid(axis="x", visible=False)
    return fig


def chart_category_distribution(frame: pd.DataFrame):
    counts = frame["AQI_Bucket"].dropna().astype(str).value_counts().reindex(AQI_BUCKET_ORDER, fill_value=0)
    counts = counts[counts > 0]
    fig, ax = base_figure((7.5, 3.7))
    bars = ax.bar(counts.index, counts.values, color=[AQI_COLORS.get(x, "#CBD5E1") for x in counts.index], width=.65)
    for b, v in zip(bars, counts.values):
        ax.text(b.get_x()+b.get_width()/2, v + max(counts.values)*.02, f"{v:,}", ha="center", fontsize=8, color=NAVY, fontweight="bold")
    ax.set_ylim(0, max(counts.values)*1.18 if len(counts) else 1)
    ax.set_ylabel("Records", fontsize=9, color="#68788D")
    ax.set_title("AQI category distribution", loc="left", fontsize=12, fontweight="bold", color=NAVY, pad=13)
    ax.tick_params(axis="x", labelrotation=25)
    ax.grid(axis="x", visible=False)
    return fig


def chart_correlation(frame: pd.DataFrame):
    cols = [c for c in POLLUTANT_FEATURES + ["AQI"] if c in frame.columns]
    corr = frame[cols].corr(numeric_only=True).fillna(0)
    fig, ax = plt.subplots(figsize=(10, 7.2), facecolor="white")
    im = ax.imshow(corr.to_numpy(), cmap="RdYlBu_r", vmin=-1, vmax=1, aspect="auto")
    ax.set_xticks(range(len(cols)), cols, rotation=43, ha="right", fontsize=8, color="#5B6C82")
    ax.set_yticks(range(len(cols)), cols, fontsize=8, color="#5B6C82")
    for i in range(len(cols)):
        for j in range(len(cols)):
            v = corr.iloc[i, j]
            ax.text(j, i, f"{v:.2f}", ha="center", va="center", fontsize=6.5, color=("white" if abs(v) > .66 else "#26364A"))
    ax.set_title("Pollutant correlation map", loc="left", fontsize=12, fontweight="bold", color=NAVY, pad=13)
    for spine in ax.spines.values():
        spine.set_visible(False)
    cbar = fig.colorbar(im, ax=ax, shrink=.8, pad=.03)
    cbar.ax.tick_params(labelsize=8, colors="#68788D")
    cbar.set_label("Pearson correlation", fontsize=8, color="#68788D")
    fig.tight_layout()
    return fig, corr


def chart_feature_importance(importance: pd.DataFrame):
    if importance is None or importance.empty:
        return None
    view = importance.sort_values("Importance", ascending=True).tail(10)
    fig, ax = base_figure((8.2, 4.3))
    bars = ax.barh(view["Feature"], view["Importance"], color=[TEAL if i >= len(view)-2 else "#90D5D0" for i in range(len(view))], height=.63)
    ax.set_xlabel("Relative feature importance", fontsize=9, color="#68788D")
    ax.set_title("Most influential pollutant inputs", loc="left", fontsize=12, fontweight="bold", color=NAVY, pad=13)
    ax.grid(axis="x", color="#EAF0F6")
    ax.grid(axis="y", visible=False)
    return fig


@st.cache_resource(show_spinner="Preparing the dataset, charts and machine-learning models…")
def cached_analysis(csv_bytes: bytes, source_name: str, signature: str):
    frame = pd.read_csv(BytesIO(csv_bytes))
    is_synthetic = ("synthetic" in source_name.lower()) or ("demo" in source_name.lower())
    if is_synthetic:
        out = OUTPUT_DIR
    else:
        out = OUTPUT_DIR / ("uploaded_" + signature[:10])
    analysis = run_analysis(frame, out, save_models=True)
    analysis["summary"]["dataset_file"] = source_name
    analysis["summary"]["is_synthetic_demo"] = is_synthetic
    with open(out / "results_summary.json", "w", encoding="utf-8") as summary_file:
        json.dump(analysis["summary"], summary_file, indent=2, ensure_ascii=False)
    return analysis


# ------------------------------- Sidebar -----------------------------------
with st.sidebar:
    st.markdown(
        '<div class="side-brand"><div class="side-brand-mark">◌</div><div><div class="side-brand-name">AeroIQ</div><div class="side-brand-sub">INDIA AIR QUALITY LAB</div></div></div>',
        unsafe_allow_html=True,
    )
    st.markdown('<div class="side-label">Data source</div>', unsafe_allow_html=True)
    uploaded = st.file_uploader("Upload your city_day.csv", type=["csv"], help="The official Kaggle dataset is recommended for final report results.")
    st.markdown("<div class='small-muted'>Required: City, Date, AQI, AQI_Bucket and pollutant columns.</div>", unsafe_allow_html=True)
    st.divider()
    st.markdown('<div class="side-label">Official dataset</div>', unsafe_allow_html=True)
    st.link_button("↗ Open Kaggle dataset", "https://www.kaggle.com/datasets/rohanrao/air-quality-data-in-india", use_container_width=True)

if uploaded is not None:
    csv_bytes = uploaded.getvalue()
    source_name = uploaded.name
    is_demo = ("synthetic" in source_name.lower()) or ("demo" in source_name.lower())
else:
    if OFFICIAL.exists():
        selected_path = OFFICIAL
        source_name = OFFICIAL.name
        is_demo = False
    else:
        selected_path = DEMO
        source_name = DEMO.name
        is_demo = True
    if not selected_path.exists():
        st.error("No dataset found. Upload the official city_day.csv or add the demo CSV to the data folder.")
        st.stop()
    csv_bytes = selected_path.read_bytes()

signature = hashlib.sha256(csv_bytes).hexdigest()
try:
    result = cached_analysis(csv_bytes, source_name, signature)
except Exception as exc:
    st.markdown('<div class="hero"><div class="hero-kicker">AeroIQ · Data workspace</div><div class="hero-title">Let’s get your data ready.</div><div class="hero-copy">The dashboard could not process the selected CSV. Check the required columns and try again.</div></div>', unsafe_allow_html=True)
    st.error(f"Dataset processing error: {exc}")
    st.info("Required columns include City, Date, AQI and AQI_Bucket. Pollutant columns should use the names in the Kaggle city_day.csv file.")
    st.stop()

data = result["cleaned"].copy()
summary = result["summary"]
reg_metrics = pd.DataFrame(summary["regression_metrics"]).rename(columns={"R2": "R²"})

# Global date filter. Model metrics continue to describe the full selected dataset.
with st.sidebar:
    st.divider()
    st.markdown('<div class="side-label">Dashboard filter</div>', unsafe_allow_html=True)
    years = sorted(data["Year"].dropna().astype(int).unique().tolist())
    year_options = ["All years"] + [str(y) for y in years]
    chosen_year = st.selectbox("Reporting year", year_options, index=0)
    if chosen_year != "All years":
        view_data = data[data["Year"] == int(chosen_year)].copy()
    else:
        view_data = data.copy()
    st.markdown('<div class="side-label">Project status</div>', unsafe_allow_html=True)
    if is_demo:
        st.warning("Synthetic demo data", icon="⚠️")
    else:
        st.success("CSV loaded", icon="✓")
    st.caption("Intelligent Data Systems 1 Lab · Experiment 10")

# ------------------------------ Main header --------------------------------
mode_label = "DEMO DATASET" if is_demo else "DATASET CONNECTED"
start_date = pd.to_datetime(data["Date"]).min().strftime("%b %Y")
end_date = pd.to_datetime(data["Date"]).max().strftime("%b %Y")
st.markdown(
    f"""
    <div class="hero">
      <div class="hero-kicker">AIR QUALITY INTELLIGENCE · INDIA</div>
      <div class="hero-title">Understand the air.<br/>Predict what comes next.</div>
      <div class="hero-copy">Explore pollution patterns across Indian cities, understand which pollutants track with AQI, and test machine-learning models on historical daily readings.</div>
      <div class="hero-chip"><span class="hero-dot"></span> {mode_label} &nbsp;·&nbsp; {start_date} — {end_date} &nbsp;·&nbsp; {data['City'].nunique()} cities</div>
    </div>
    """,
    unsafe_allow_html=True,
)

if is_demo:
    st.markdown(
        '<div class="status-note"><strong>Demo mode:</strong> This dataset is synthetic and is only included to test the application. City rankings, trends, correlations and model scores are not real Indian air-quality findings. Upload the official Kaggle <code>city_day.csv</code> before preparing final results.</div>',
        unsafe_allow_html=True,
    )
else:
    st.markdown(
        f'<div class="success-note"><strong>Dataset ready:</strong> Results are calculated from <code>{source_name}</code>. The charts and model metrics update for the selected dataset.</div>',
        unsafe_allow_html=True,
    )

if chosen_year != "All years" and view_data.empty:
    st.warning("No data found for this year. Select another year from the sidebar.")
    st.stop()

avg_aqi = float(view_data["AQI"].mean()) if len(view_data) else 0.0
category = aqi_category(avg_aqi)
worst_city_row = view_data.groupby("City")["AQI"].mean().sort_values(ascending=False)
worst_city = str(worst_city_row.index[0]) if len(worst_city_row) else "—"
best_model_row = reg_metrics.sort_values("RMSE").iloc[0] if len(reg_metrics) else None
cls_summary = summary.get("classification", {})
cls_accuracy = cls_summary.get("accuracy")

# Top row metrics
k1, k2, k3, k4 = st.columns(4)
k1.metric("Daily records", f"{len(view_data):,}", help="Records currently included by the year filter.")
k2.metric("Cities covered", f"{view_data['City'].nunique():,}")
k3.metric("Average AQI", f"{avg_aqi:.1f}", delta=category, delta_color="off", help="Category reflects the average AQI in the selected view.")
k4.metric("Classifier accuracy", f"{cls_accuracy:.1%}" if cls_accuracy is not None else "N/A", help="Random Forest category accuracy on a held-out test split for the full selected dataset.")

# -------------------------------- Navigation --------------------------------
overview_tab, trends_tab, models_tab, predict_tab, data_tab = st.tabs(
    ["◈  Overview", "⌁  City & seasonal trends", "◎  Model lab", "✳  Predict AQI", "▤  Data & method"]
)

with overview_tab:
    section_heading("At a glance", "Pollution snapshot", "A fast read of the selected period. Use the year filter in the sidebar to focus the view.")
    row1_left, row1_right = st.columns([1.45, 1])
    with row1_left:
        with st.container(border=True):
            panel_heading("Monthly AQI trend", "The line shows the mean AQI for each calendar month.")
            fig = chart_monthly(view_data)
            st.pyplot(fig, use_container_width=True)
            plt.close(fig)
    with row1_right:
        with st.container(border=True):
            panel_heading("Seasonal profile", "Season definitions: winter, summer, monsoon and post-monsoon.")
            fig = chart_seasonal(view_data)
            st.pyplot(fig, use_container_width=True)
            plt.close(fig)
    row2_left, row2_right = st.columns([1.45, 1])
    with row2_left:
        with st.container(border=True):
            fig, top_cities = chart_city_rankings(view_data, top_n=9)
            panel_heading("Highest-AQI cities", "Ranked by average AQI in the current view; higher generally means worse air quality.")
            st.pyplot(fig, use_container_width=True)
            plt.close(fig)
            display_top = top_cities.head(3).copy()
            display_top["AQI"] = display_top["AQI"].round(1)
            display_top.insert(0, "Rank", range(1, len(display_top)+1))
            st.dataframe(display_top.rename(columns={"City": "City", "AQI": "Average AQI"}), hide_index=True, use_container_width=True)
    with row2_right:
        with st.container(border=True):
            panel_heading("AQI category mix", "Counts are based on the AQI_Bucket labels recorded in the dataset.")
            fig = chart_category_distribution(view_data)
            st.pyplot(fig, use_container_width=True)
            plt.close(fig)
    strongest = sorted(summary.get("correlations_with_aqi", {}).items(), key=lambda item: abs(item[1]), reverse=True)[:3]
    st.markdown("#### Signals worth investigating")
    s1, s2, s3 = st.columns(3)
    for col, pair in zip([s1, s2, s3], strongest):
        pollutant, corr_value = pair
        with col:
            st.markdown(
                f'<div class="insight-card"><div class="insight-label">AQI correlation</div><div class="insight-value">{pollutant}</div><div class="insight-sub">Pearson r = {corr_value:.2f} · association, not causation</div></div>',
                unsafe_allow_html=True,
            )

with trends_tab:
    section_heading("Explore patterns", "City & seasonal trends", "Compare locations and inspect how average AQI changes over time.")
    city_choices = sorted(view_data["City"].dropna().astype(str).unique().tolist())
    default_cities = view_data.groupby("City")["AQI"].mean().sort_values(ascending=False).head(min(5, len(city_choices))).index.astype(str).tolist()
    chosen_cities = st.multiselect("Compare cities", options=city_choices, default=default_cities, help="Choose one or more cities to compare monthly averages.")
    if chosen_cities:
        compare = view_data[view_data["City"].isin(chosen_cities)].groupby(["Month", "City"], as_index=False)["AQI"].mean()
        pivot = compare.pivot(index="Month", columns="City", values="AQI").reindex(range(1,13))
        pivot.index = [MONTH_NAMES[m-1] for m in pivot.index]
        with st.container(border=True):
            panel_heading("Monthly comparison", "Mean AQI by calendar month for the selected cities.")
            st.line_chart(pivot, use_container_width=True, height=330)
    else:
        st.info("Select at least one city to render the monthly comparison.")
    left, right = st.columns(2)
    with left:
        with st.container(border=True):
            panel_heading("Yearly AQI trajectory", "The complete selected dataset is used when all years are selected.")
            fig = chart_yearly(view_data)
            st.pyplot(fig, use_container_width=True)
            plt.close(fig)
    with right:
        with st.container(border=True):
            fig, corr = chart_correlation(view_data)
            panel_heading("Pollutant relationships", "Values close to +1 or −1 indicate stronger linear association.")
            st.pyplot(fig, use_container_width=True)
            plt.close(fig)
            corr_aqi = corr["AQI"].drop(labels=["AQI"], errors="ignore").sort_values(key=lambda x: x.abs(), ascending=False).head(6)
            corr_view = pd.DataFrame({"Pollutant": corr_aqi.index, "Correlation with AQI": corr_aqi.values})
            st.dataframe(corr_view.style.format({"Correlation with AQI": "{:.3f}"}), hide_index=True, use_container_width=True)

with models_tab:
    section_heading("Machine learning", "Model performance lab", "Compare numerical AQI prediction models and inspect AQI category classification.")
    st.markdown("**Regression · predict the AQI value**")
    reg_show = reg_metrics.sort_values("RMSE").copy()
    col_metric1, col_metric2 = st.columns([1.05, 1.35])
    with col_metric1:
        if best_model_row is not None:
            st.markdown(
                f'<div class="insight-card"><div class="insight-label">Lowest RMSE</div><div class="insight-value">{best_model_row["Model"]}</div><div class="insight-sub">R² = {best_model_row["R²"]:.3f} · RMSE = {best_model_row["RMSE"]:.2f} · MAE = {best_model_row["MAE"]:.2f}</div></div>',
                unsafe_allow_html=True,
            )
        st.write("")
        st.dataframe(reg_show.style.format({"R²": "{:.3f}", "RMSE": "{:.2f}", "MAE": "{:.2f}"}), hide_index=True, use_container_width=True)
        st.download_button("Download regression metrics", data=reg_show.to_csv(index=False).encode("utf-8"), file_name="regression_metrics.csv", mime="text/csv", use_container_width=True)
    with col_metric2:
        with st.container(border=True):
            panel_heading("Model error comparison", "Lower RMSE means smaller typical prediction error; scale is AQI points.")
            rmse_plot = reg_show.sort_values("RMSE", ascending=True).set_index("Model")[["RMSE"]]
            st.bar_chart(rmse_plot, color="#0E9F9A", use_container_width=True, height=285)
    left, right = st.columns(2)
    with left:
        with st.container(border=True):
            panel_heading("Actual vs predicted", "Points closer to the diagonal indicate stronger predictions on test data.")
            chart_path = summary.get("charts", {}).get("actual_vs_predicted")
            if chart_path and Path(chart_path).exists():
                st.image(chart_path, use_container_width=True)
            else:
                st.info("Run training to generate the actual-vs-predicted chart.")
    with right:
        with st.container(border=True):
            panel_heading("Feature importance", "Random Forest feature importances are relative model signals, not proof of causality.")
            fig = chart_feature_importance(result.get("feature_importance"))
            if fig is not None:
                st.pyplot(fig, use_container_width=True)
                plt.close(fig)
            else:
                st.info("Feature importance is not available for this dataset.")
    st.markdown("**Classification · predict AQI category**")
    ca, cb = st.columns([.8, 1.2])
    with ca:
        if cls_accuracy is not None:
            st.metric("Random Forest accuracy", f"{cls_accuracy:.1%}")
            report = cls_summary.get("report", {})
            classification_rows = []
            for label in AQI_BUCKET_ORDER:
                if label in report:
                    classification_rows.append({"Category": label, "Precision": report[label]["precision"], "Recall": report[label]["recall"], "F1-score": report[label]["f1-score"], "Support": int(report[label]["support"])})
            if classification_rows:
                st.dataframe(pd.DataFrame(classification_rows).style.format({"Precision":"{:.2f}", "Recall":"{:.2f}", "F1-score":"{:.2f}"}), hide_index=True, use_container_width=True)
        else:
            st.info("A category model could not be trained from the selected dataset's available labels.")
    with cb:
        with st.container(border=True):
            panel_heading("Confusion matrix", "Rows are actual categories; columns are model predictions.")
            cm_path = summary.get("charts", {}).get("confusion_matrix")
            if cm_path and Path(cm_path).exists():
                st.image(cm_path, use_container_width=True)
            else:
                st.info("Confusion matrix is not available.")
    st.markdown(
        '<div class="status-note"><strong>How to interpret this:</strong> AQI and AQI categories are derived from pollutant readings, so high test scores do not automatically mean the model can forecast future air quality. A time-based evaluation would be a stricter forecasting test.</div>',
        unsafe_allow_html=True,
    )

with predict_tab:
    section_heading("Interactive prediction", "Estimate AQI from pollutant readings", "Enter concentrations in the same units and approximate ranges as the training dataset. This is a classroom demonstration, not a live CPCB reading.")
    medians = data[POLLUTANT_FEATURES].median(numeric_only=True)
    st.markdown("##### Pollutant inputs")
    with st.form("pollutant_prediction_form", clear_on_submit=False):
        st.markdown("<div class='small-muted'>All fields are non-negative. Defaults are the median readings in the selected dataset.</div>", unsafe_allow_html=True)
        values = {}
        pollutant_cols = st.columns(3)
        for i, feature in enumerate(POLLUTANT_FEATURES):
            default_value = medians.get(feature, 0.0)
            if not np.isfinite(default_value):
                default_value = 0.0
            with pollutant_cols[i % 3]:
                values[feature] = st.number_input(
                    POLLUTANT_LABELS.get(feature, feature),
                    min_value=0.0,
                    max_value=1_000_000.0,
                    value=float(round(default_value, 2)),
                    step=1.0,
                    format="%.2f",
                    help=f"Dataset median: {default_value:.2f}",
                    key=f"pollutant_{feature}",
                )
        predict_submit = st.form_submit_button("✦  Predict air quality", type="primary", use_container_width=True)
    if predict_submit:
        sample = pd.DataFrame([values], columns=POLLUTANT_FEATURES)
        chosen_model = result["regression_models"].get("Random Forest")
        if chosen_model is None:
            chosen_model = result["regression_models"][summary["best_regression_model"]]
        predicted_aqi = float(chosen_model.predict(sample)[0])
        predicted_aqi = max(0.0, predicted_aqi)
        predicted_band = aqi_category(predicted_aqi)
        class_model = result.get("classification_model")
        pred_label = str(class_model.predict(sample)[0]) if class_model is not None else predicted_band
        pleft, pright = st.columns([1, 1.1])
        with pleft:
            st.markdown(
                f'<div class="prediction-card"><div class="prediction-label">Estimated numerical AQI</div><div class="prediction-number">{predicted_aqi:.1f}</div><span class="category-pill" style="background:{AQI_COLORS[predicted_band]}">{predicted_band}</span><div class="prediction-muted" style="margin-top:13px">Category estimated from the predicted AQI value.</div></div>',
                unsafe_allow_html=True,
            )
        with pright:
            st.markdown(
                f'<div class="insight-card"><div class="insight-label">Classifier output</div><div class="insight-value">{pred_label}</div><div class="insight-sub">Random Forest category model trained from recorded AQI_Bucket labels.</div><hr style="border:0;border-top:1px solid #E4EAF2;margin:18px 0"><div class="insight-label">Interpretation band</div><div style="font-weight:800;font-size:1rem;color:{AQI_COLORS[predicted_band]};margin-top:6px">{predicted_band}</div><div class="insight-sub">The numeric model and the category classifier can disagree because they are trained as separate tasks.</div></div>',
                unsafe_allow_html=True,
            )
        st.markdown("<div class='small-muted'>Educational prediction only. Do not use this result as an official real-time AQI, an exposure assessment, or medical advice.</div>", unsafe_allow_html=True)

with data_tab:
    section_heading("Dataset workspace", "Data quality & method", "Review the selected data source, cleaning summary and downloadable outputs.")
    clean = summary["cleaning"]
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Input rows", f"{clean['input_rows']:,}")
    c2.metric("Duplicates removed", f"{clean['duplicates_removed']:,}")
    c3.metric("Rows after cleaning", f"{clean['rows_after_cleaning']:,}")
    c4.metric("Missing category labels", f"{clean['missing_aqi_bucket_rows']:,}")
    with st.container(border=True):
        panel_heading("Cleaning pipeline", "The same steps are used whether the source is the demo file or an uploaded CSV.")
        clean_steps = [
            ("01", "Validate columns", "Check that City, Date, AQI and AQI_Bucket exist."),
            ("02", "Remove duplicates", f"Removed {clean['duplicates_removed']:,} exact duplicate rows."),
            ("03", "Clean target fields", "Convert Date and AQI to usable types, then remove records without a valid date, city or AQI."),
            ("04", "Prepare features", "Convert pollutant readings to numeric values and derive Year, Month, MonthName and Season."),
            ("05", "Fit with imputation", "Median imputation is fitted inside each model pipeline using the training split."),
            ("06", "Evaluate", "Use an 80/20 random train-test split with random_state=42; report R², RMSE and MAE for regression."),
        ]
        for step_no, step_title, step_description in clean_steps:
            st.markdown(
                f'<div style="display:flex;gap:13px;padding:11px 0;border-bottom:1px solid #EEF2F7"><div style="font-family:Manrope,sans-serif;color:#0E9F9A;font-weight:800;font-size:.82rem;min-width:28px">{step_no}</div><div><div style="font-weight:800;color:#223249;font-size:.86rem">{step_title}</div><div style="font-size:.79rem;color:#718096;margin-top:2px">{step_description}</div></div></div>',
                unsafe_allow_html=True,
            )
    with st.container(border=True):
        panel_heading("Cleaned data preview", "Preview of up to 100 records after data preparation.")
        preview = view_data.head(100)
        st.dataframe(preview, hide_index=True, use_container_width=True, height=370)
        st.download_button("Download filtered cleaned data (CSV)", data=view_data.to_csv(index=False).encode("utf-8"), file_name="cleaned_air_quality.csv", mime="text/csv")
    with st.container(border=True):
        panel_heading("Project files", "Download the files used in your lab analysis.")
        d1, d2, d3 = st.columns(3)
        with d1:
            st.download_button("↓ Cleaned data", data=data.to_csv(index=False).encode("utf-8"), file_name="cleaned_data.csv", mime="text/csv", use_container_width=True)
        with d2:
            st.download_button("↓ Regression metrics", data=reg_metrics.to_csv(index=False).encode("utf-8"), file_name="regression_metrics.csv", mime="text/csv", use_container_width=True)
        with d3:
            summary_bytes = json.dumps(summary, indent=2, default=str).encode("utf-8")
            st.download_button("↓ Results summary JSON", data=summary_bytes, file_name="results_summary.json", mime="application/json", use_container_width=True)

st.markdown(
    '<div class="footer">AeroIQ · Intelligent Data Systems 1 Lab · Experiment 10<br/>Analysis is based only on the selected dataset. Demo observations are synthetic.</div>',
    unsafe_allow_html=True,
)
