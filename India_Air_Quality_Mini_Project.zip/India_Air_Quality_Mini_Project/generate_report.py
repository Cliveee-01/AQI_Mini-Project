"""Generate the lab report from outputs/results_summary.json.
Run `python train_models.py` first, then `python generate_report.py`.
"""
from pathlib import Path
import json
import pandas as pd
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "outputs"
REPORT_DIR = ROOT / "reports"
REPORT_DIR.mkdir(parents=True, exist_ok=True)
SUMMARY_PATH = OUT / "results_summary.json"
if not SUMMARY_PATH.exists():
    raise SystemExit("Missing outputs/results_summary.json. Run python train_models.py first.")
summary = json.loads(SUMMARY_PATH.read_text(encoding="utf-8"))
metrics = pd.read_csv(OUT / "regression_metrics.csv") if (OUT / "regression_metrics.csv").exists() else pd.DataFrame()
is_demo = bool(summary.get("is_synthetic_demo", "demo_synthetic" in summary.get("dataset_file", "")))

NAVY = "16324F"
TEAL = "087E8B"
PALE = "EAF4F4"
LIGHT = "F1F5F9"
DARK = "243447"
MUTED = "5D6B78"
RED = "9B1C1C"


def shade(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    tcPr.append(shd)


def set_cell_text(cell, text, bold=False, color=DARK, size=9):
    cell.text = ""
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(0)
    r = p.add_run(str(text))
    r.bold = bold
    r.font.name = "Aptos"
    r.font.size = Pt(size)
    r.font.color.rgb = RGBColor.from_string(color)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def format_table(table, header=True, font_size=9):
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = "Table Grid"
    for i, row in enumerate(table.rows):
        for cell in row.cells:
            cell.margin_top = 50
            cell.margin_bottom = 50
            if header and i == 0:
                shade(cell, NAVY)
                set_cell_text(cell, cell.text, bold=True, color="FFFFFF", size=font_size)
            else:
                if i % 2 == 0:
                    shade(cell, LIGHT)
                set_cell_text(cell, cell.text, size=font_size)


def add_table(doc, headers, rows, widths=None, font_size=9):
    table = doc.add_table(rows=1, cols=len(headers))
    for i, h in enumerate(headers):
        table.rows[0].cells[i].text = str(h)
    for row in rows:
        cells = table.add_row().cells
        for i, value in enumerate(row):
            cells[i].text = str(value)
    format_table(table, True, font_size)
    if widths:
        for row in table.rows:
            for i, width in enumerate(widths):
                row.cells[i].width = Inches(width)
    doc.add_paragraph().paragraph_format.space_after = Pt(1)
    return table


def heading(doc, text, level=1):
    p = doc.add_paragraph(style=f"Heading {level}")
    p.paragraph_format.keep_with_next = True
    p.add_run(text)
    return p


def para(doc, text, bold_prefix=None):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.line_spacing = 1.08
    if bold_prefix and text.startswith(bold_prefix):
        p.add_run(bold_prefix).bold = True
        p.add_run(text[len(bold_prefix):])
    else:
        p.add_run(text)
    return p


def bullet(doc, text):
    p = doc.add_paragraph(style="List Bullet")
    p.paragraph_format.space_after = Pt(2)
    p.paragraph_format.left_indent = Inches(0.23)
    p.add_run(text)
    return p


def add_image(doc, key, width=6.4, caption=None):
    path = summary.get("charts", {}).get(key)
    if not path:
        path = str(OUT / (key + ".png"))
    pth = Path(path)
    if pth.exists():
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_after = Pt(2)
        p.add_run().add_picture(str(pth), width=Inches(width))
        if caption:
            cap = doc.add_paragraph()
            cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
            cap.paragraph_format.space_after = Pt(5)
            r = cap.add_run(caption)
            r.italic = True
            r.font.size = Pt(8)
            r.font.color.rgb = RGBColor.from_string(MUTED)


def add_image_pair(doc, key_left, key_right, captions):
    """Place two charts on one row to avoid near-empty spillover pages."""
    from docx.enum.table import WD_TABLE_ALIGNMENT
    table = doc.add_table(rows=1, cols=2)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    keys = [key_left, key_right]
    for i, key in enumerate(keys):
        cell = table.rows[0].cells[i]
        cell.width = Inches(3.15)
        cell.text = ""
        pth_value = summary.get("charts", {}).get(key)
        pth = Path(pth_value) if pth_value else OUT / (key + ".png")
        if pth.exists():
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.space_after = Pt(2)
            p.add_run().add_picture(str(pth), width=Inches(3.0))
            cp = cell.add_paragraph()
            cp.alignment = WD_ALIGN_PARAGRAPH.CENTER
            cp.paragraph_format.space_after = Pt(0)
            rr = cp.add_run(captions[i])
            rr.italic = True
            rr.font.size = Pt(7.5)
            rr.font.color.rgb = RGBColor.from_string(MUTED)
    doc.add_paragraph().paragraph_format.space_after = Pt(1)


def add_page_number(paragraph):
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = paragraph.add_run("Page ")
    fld = OxmlElement("w:fldSimple")
    fld.set(qn("w:instr"), "PAGE")
    run._r.addnext(fld)


doc = Document()
sec = doc.sections[0]
sec.top_margin = Inches(0.62)
sec.bottom_margin = Inches(0.62)
sec.left_margin = Inches(0.72)
sec.right_margin = Inches(0.72)

styles = doc.styles
styles["Normal"].font.name = "Aptos"
styles["Normal"].font.size = Pt(9.5)
styles["Normal"].font.color.rgb = RGBColor.from_string(DARK)
styles["Normal"].paragraph_format.space_after = Pt(4)
for sname, size, color in [("Title", 30, NAVY), ("Heading 1", 16, NAVY), ("Heading 2", 12, TEAL), ("Heading 3", 10, NAVY)]:
    st = styles[sname]
    st.font.name = "Aptos Display" if sname in ("Title", "Heading 1") else "Aptos"
    st.font.size = Pt(size)
    st.font.bold = True
    st.font.color.rgb = RGBColor.from_string(color)
    st.paragraph_format.space_before = Pt(7)
    st.paragraph_format.space_after = Pt(4)

header = sec.header.paragraphs[0]
header.text = "INTELLIGENT DATA SYSTEMS 1 LAB  |  EXPERIMENT 10"
header.alignment = WD_ALIGN_PARAGRAPH.RIGHT
for r in header.runs:
    r.font.name = "Aptos"
    r.font.size = Pt(8)
    r.font.color.rgb = RGBColor.from_string(MUTED)
footer = sec.footer.paragraphs[0]
add_page_number(footer)
for r in footer.runs:
    r.font.size = Pt(8)
    r.font.color.rgb = RGBColor.from_string(MUTED)

# COVER
p = doc.add_paragraph()
p.paragraph_format.space_before = Pt(72)
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = p.add_run("MINI PROJECT REPORT")
r.bold = True; r.font.name = "Aptos"; r.font.size = Pt(15); r.font.color.rgb = RGBColor.from_string(TEAL)
p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.paragraph_format.space_before = Pt(18)
r = p.add_run("India Air Quality\n(AQI) Analysis and Prediction")
r.bold = True; r.font.name = "Aptos Display"; r.font.size = Pt(28); r.font.color.rgb = RGBColor.from_string(NAVY)
p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.paragraph_format.space_before = Pt(12)
r = p.add_run("Experiment 10 - To Implement Mini Project")
r.font.size = Pt(14); r.font.color.rgb = RGBColor.from_string(MUTED)
p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.paragraph_format.space_before = Pt(24)
r = p.add_run("Course: Intelligent Data Systems 1 Lab")
r.bold = True; r.font.size = Pt(12)

add_table(doc, ["Student details", "Fill before submission"], [
    ["Name", "[Your name]"], ["Roll number", "[Your roll number]"], ["Date", "[Date of submission]"]
], widths=[2.0,4.3], font_size=10)
p=doc.add_paragraph()
p.alignment=WD_ALIGN_PARAGRAPH.CENTER
p.paragraph_format.space_before=Pt(26)
r=p.add_run("Tools: Python  |  pandas  |  matplotlib  |  scikit-learn  |  Streamlit")
r.font.size=Pt(10); r.font.color.rgb=RGBColor.from_string(TEAL)
if is_demo:
    p=doc.add_paragraph()
    p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before=Pt(24)
    r=p.add_run("IMPORTANT: CURRENT OUTPUTS ARE DEMO-ONLY")
    r.bold=True; r.font.size=Pt(11); r.font.color.rgb=RGBColor.from_string(RED)
    p=doc.add_paragraph("This package currently uses a synthetic sample dataset so the code can be tested immediately. Replace it with the official Kaggle city_day.csv, rerun the training script, and regenerate this report before submitting real-world findings.")
    p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    for r in p.runs: r.font.size=Pt(9); r.font.color.rgb=RGBColor.from_string(RED)
doc.add_page_break()

# 1-4
heading(doc,"1. Aim",1)
para(doc,"To analyse air-quality data from Indian cities, identify city-wise and seasonal pollution patterns, examine the relationship between pollutant concentrations and AQI, and build machine-learning models to predict AQI value and category.")
heading(doc,"2. Introduction and Problem Statement",1)
para(doc,"Air pollution is an important public-health concern. The Air Quality Index (AQI) expresses pollution levels as a value and a category that are easier to communicate than individual pollutant concentrations. This project explores historical city-day data and uses supervised learning to estimate numeric AQI and the recorded AQI category from pollutant readings.")
for t in ["Which cities and months have the highest average AQI?","Which pollutant readings have the strongest correlation with AQI?","How well can regression and classification models predict AQI from pollutant concentrations?"]:
    bullet(doc,t)
heading(doc,"3. Tools and Technologies",1)
add_table(doc,["Tool","Purpose"],[
    ["Python 3","Project programming language"],["pandas / NumPy","Data cleaning and numerical operations"],["matplotlib","Charts and visual exploration"],["scikit-learn","Imputation, training, splitting and evaluation"],["Streamlit","Interactive web dashboard and prediction form"]
],widths=[1.7,4.6],font_size=9)
heading(doc,"4. Dataset Description",1)
rows = [
    ["City, Date", "City name and date of daily reading"],
    ["PM2.5, PM10", "Fine and coarse particulate matter"],
    ["NO, NO2, NOx, NH3", "Nitrogen compounds and ammonia"],
    ["CO, SO2, O3", "Carbon monoxide, sulphur dioxide and ozone"],
    ["Benzene, Toluene, Xylene", "Volatile organic compound measurements"],
    ["AQI", "Numeric target for the regression models"],
    ["AQI_Bucket", "Recorded AQI category for classification"]
]
add_table(doc,["Column(s)","Meaning"],rows,widths=[2.1,4.2],font_size=8.5)
para(doc,"Expected official dataset: Kaggle, Air Quality Data in India (2015-2020), file city_day.csv. The commonly described source contains 29,531 city-day records and 16 columns for 26 cities, with data spanning 2015 to 2020; exact usable row counts can change after cleaning.")
if is_demo:
    para(doc,f"Dataset currently used for this run: synthetic demo CSV ({summary['cleaning']['input_rows']:,} input rows; {summary['cleaning']['rows_after_cleaning']:,} rows after cleaning; {summary['cleaning']['cities']} demo cities). These counts are not the official dataset counts.")
else:
    para(doc,f"Dataset used for this run: {summary.get('dataset_file','city_day.csv')} ({summary['cleaning']['input_rows']:,} input rows; {summary['cleaning']['rows_after_cleaning']:,} rows after cleaning; {summary['cleaning']['cities']} cities).")

doc.add_page_break()
heading(doc,"5. Methodology",1)
para(doc,"The pipeline follows: load data -> clean data -> exploratory data analysis -> train models -> evaluate models -> conclude.")
heading(doc,"5.1 Data Cleaning",2)
for t in [
    f"Removed {summary['cleaning']['duplicates_removed']:,} duplicate rows.",
    "Parsed Date as a date field and removed records without a usable date, city or numeric AQI target.",
    "Converted pollutant columns to numeric values; missing pollutant readings are imputed with the median inside each model pipeline, fitted on the training split only.",
    "Extracted Year, Month, MonthName and Season for exploratory analysis.",
    f"{summary['cleaning']['rows_after_cleaning']:,} rows remained after cleaning. Rows without AQI_Bucket are omitted from the classification task only."
]: bullet(doc,t)
heading(doc,"5.2 Exploratory Data Analysis",2)
para(doc,"The analysis calculates average AQI by city, month, year and season; counts the recorded AQI categories; and visualises correlations between pollutant readings and AQI. Correlation indicates association and should not be interpreted as proof of causation.")
heading(doc,"5.3 Machine-Learning Models",2)
add_table(doc,["Task","Model","Purpose"],[
    ["Regression","Linear Regression","Simple linear baseline"],
    ["Regression","Decision Tree Regressor","Captures nonlinear splits"],
    ["Regression","Random Forest Regressor (100 trees)","Ensemble model for comparison"],
    ["Classification","Random Forest Classifier (100 trees)","Predicts AQI_Bucket category"]
],widths=[1.2,2.5,2.6],font_size=8.5)
para(doc,"A random 80% training / 20% testing split is used with random_state = 42. Pollutant measurements are the features. AQI is not used as an input to category classification, and AQI_Bucket is not used as an input to numeric AQI regression.")
heading(doc,"5.4 Evaluation Metrics",2)
para(doc,"Regression: R-squared (R²), root mean squared error (RMSE) and mean absolute error (MAE). Classification: accuracy, precision, recall, F1-score and confusion matrix.")

# EDA

doc.add_page_break()
heading(doc,"6.1. Exploratory Data Analysis Findings",1)
if is_demo:
    para(doc,"The findings below describe only the included synthetic demonstration data. They are shown to demonstrate how results are generated; do not present them as facts about real Indian air quality.")
else:
    para(doc,"The following observations are calculated from the selected city-day dataset after cleaning.")
para(doc,"Highest average AQI cities in the selected data:")
for row in summary.get("top_cities_by_aqi",[]):
    bullet(doc,f"{row['City']}: {float(row['AQI']):.2f} average AQI")
seasonal = summary.get("seasonal_averages",[])
if seasonal:
    best_season = max(seasonal,key=lambda x:x['AQI'])
    clean_season = min(seasonal,key=lambda x:x['AQI'])
    para(doc,f"Seasonal summary: highest mean AQI was {best_season['Season']} ({best_season['AQI']:.2f}); lowest mean AQI was {clean_season['Season']} ({clean_season['AQI']:.2f}) in this dataset.")
years = summary.get("yearly_averages",[])
if len(years)>=2:
    direction = "increased" if years[-1]['AQI'] > years[0]['AQI'] else "decreased" if years[-1]['AQI'] < years[0]['AQI'] else "was unchanged"
    para(doc,f"Yearly trend: average AQI {direction} from {years[0]['Year']} ({years[0]['AQI']:.2f}) to {years[-1]['Year']} ({years[-1]['AQI']:.2f}).")
strong = summary.get("strongest_abs_correlations",[])
if strong:
    para(doc,"Strongest absolute correlations with AQI:")
    for row in strong[:3]: bullet(doc,f"{row['feature']}: r = {row['correlation']:.3f}")
add_image(doc,"eda",width=6.4,caption="Figure 1. City, monthly, yearly, and AQI category overview.")

# regression

doc.add_page_break()
add_image(doc,"correlation",width=3.8,caption="Figure 2. Correlation between pollutant readings and numeric AQI.")
heading(doc,"6.2. Regression Results",1)
if is_demo:
    para(doc,"DEMO-ONLY metrics from synthetic data. They confirm that the pipeline runs; they are not a benchmark for the official dataset.")
else:
    para(doc,"Metrics below were computed on the held-out test partition of the selected dataset.")
metric_rows=[]
for _,row in metrics.iterrows():
    metric_rows.append([row["Model"],f"{row['R2']:.4f}",f"{row['RMSE']:.2f}",f"{row['MAE']:.2f}"])
add_table(doc,["Model","R²","RMSE","MAE"],metric_rows,widths=[2.5,1.0,1.2,1.2],font_size=9)
bestrow = min(summary.get("regression_metrics",[]),key=lambda x:x["RMSE"]) if summary.get("regression_metrics") else None
if bestrow:
    para(doc,f"Best model by RMSE: {bestrow['Model']} (RMSE = {bestrow['RMSE']:.2f}; R² = {bestrow['R2']:.4f}; MAE = {bestrow['MAE']:.2f}).")
para(doc,"Feature importance from the Random Forest Regressor indicates which inputs the fitted model used most for its splits. Importance is model-specific and does not prove a pollutant causes the AQI change.")
add_image_pair(doc,"actual_vs_predicted","feature_importance",[
    "Figure 3. Actual versus predicted AQI using the lowest-RMSE model.",
    "Figure 4. Random Forest feature importance."
])

# Classification + conclusion etc.

doc.add_page_break()
heading(doc,"6.3. Classification Results",1)
cls = summary.get("classification",{})
if cls.get("accuracy") is not None:
    para(doc,f"Random Forest Classifier accuracy: {cls['accuracy']:.3f} ({cls['accuracy']:.1%}) on the held-out test partition. Classification used {cls.get('n_rows',0):,} rows with a recorded AQI_Bucket label before the train-test split.")
    report = cls.get("report",{})
    cls_rows=[]
    for label in ["Good","Satisfactory","Moderate","Poor","Very Poor","Severe"]:
        if label in report:
            rr=report[label]
            cls_rows.append([label,f"{rr['precision']:.2f}",f"{rr['recall']:.2f}",f"{rr['f1-score']:.2f}",int(rr['support'])])
    if cls_rows:
        add_table(doc,["Category","Precision","Recall","F1-score","Support"],cls_rows,widths=[1.7,1,1,1,1],font_size=8.5)
    add_image(doc,"confusion_matrix",width=5.2,caption="Figure 5. Confusion matrix for AQI category classification.")
else:
    para(doc,"Classification was not run because the selected dataset had too few usable AQI_Bucket labels.")
para(doc,"Errors may occur between neighbouring AQI categories because category boundaries are fixed while pollutant concentrations and measurements vary. The model predicts dataset labels and is not a replacement for the official CPCB AQI reporting process.")
heading(doc,"6.4. Important Observation",2)
para(doc,"AQI is derived from pollutant readings, so a model that receives pollutant inputs may learn much of the relationship used to produce AQI. High evaluation scores therefore do not automatically mean the model can forecast future AQI. Exploratory analysis and time-based evaluation are important for understanding the data and testing future-day performance.")
heading(doc,"7. Conclusion",1)
para(doc,"The project implements an end-to-end workflow for cleaning city-day air-quality data, visualising pollution patterns, comparing regression models and predicting AQI categories. The selected data determines the reported city rankings, seasonal pattern, feature relationships and metric values. Random Forest is compared against simpler models using a fixed held-out test split.")
if is_demo:
    para(doc,"Before final submission: download the official Kaggle city_day.csv, save it as data/city_day.csv, run python train_models.py, then run python generate_report.py. Replace the synthetic demo results with the newly generated official-data results.")
heading(doc,"8. Limitations and Future Scope",1)
for t in [
    "Random train-test split does not fully test prediction on future dates; a chronological split is a useful next step.",
    "Weather and meteorological factors such as temperature, humidity, wind direction and wind speed are not included.",
    "Future work can use historical lag features to forecast next-day AQI rather than estimating AQI from same-day pollutant readings.",
    "A Streamlit dashboard is included for interactive exploration and educational predictions."
]: bullet(doc,t)
heading(doc,"9. References",1)
for t in [
    "Rohan Rao, Air Quality Data in India (2015-2020), Kaggle: https://www.kaggle.com/datasets/rohanrao/air-quality-data-in-india",
    "Central Pollution Control Board (CPCB), India: https://cpcb.nic.in/",
    "scikit-learn documentation: https://scikit-learn.org/stable/",
    "pandas documentation: https://pandas.pydata.org/docs/",
    "Streamlit documentation: https://docs.streamlit.io/"
]: bullet(doc,t)

out_file = REPORT_DIR / "Mini_Project_Report.docx"
doc.save(out_file)
print(f"Report generated: {out_file}")
