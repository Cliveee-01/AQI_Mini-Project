"""Reusable data cleaning, EDA, and machine-learning pipeline for the AQI mini project."""
from __future__ import annotations
from pathlib import Path
from io import BytesIO
import json, hashlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.metrics import (r2_score, mean_squared_error, mean_absolute_error,
    accuracy_score, classification_report, confusion_matrix, ConfusionMatrixDisplay)
import joblib

POLLUTANT_FEATURES = ["PM2.5", "PM10", "NO", "NO2", "NOx", "NH3", "CO", "SO2", "O3", "Benzene", "Toluene", "Xylene"]
AQI_BUCKET_ORDER = ["Good", "Satisfactory", "Moderate", "Poor", "Very Poor", "Severe"]
SEASON_ORDER = ["Winter", "Summer", "Monsoon", "Post-monsoon"]
MONTH_NAMES = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]


def load_csv_bytes(csv_bytes: bytes) -> pd.DataFrame:
    return pd.read_csv(BytesIO(csv_bytes))


def clean_data(df: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Basic cleaning. Model imputers are fitted only on the training split to avoid leakage."""
    data = df.copy()
    data.columns = [str(c).strip() for c in data.columns]
    required = {"City", "Date", "AQI", "AQI_Bucket"}
    missing = required.difference(data.columns)
    if missing:
        raise ValueError("CSV is missing required columns: " + ", ".join(sorted(missing)))
    for col in POLLUTANT_FEATURES:
        if col not in data.columns:
            data[col] = np.nan
        data[col] = pd.to_numeric(data[col], errors="coerce")
    data["AQI"] = pd.to_numeric(data["AQI"], errors="coerce")
    before = len(data)
    data = data.drop_duplicates().copy()
    duplicates_removed = before - len(data)
    data["Date"] = pd.to_datetime(data["Date"], errors="coerce")
    data = data.dropna(subset=["Date", "AQI", "City"]).copy()
    # Normalize common text inconsistencies but preserve target labels as recorded.
    data["City"] = data["City"].astype(str).str.strip()
    data["AQI_Bucket"] = data["AQI_Bucket"].astype("string").str.strip()
    data.loc[data["AQI_Bucket"].isin(["", "nan", "None", "<NA>"]), "AQI_Bucket"] = pd.NA
    data["Year"] = data["Date"].dt.year
    data["Month"] = data["Date"].dt.month
    data["MonthName"] = data["Month"].map(dict(enumerate(MONTH_NAMES, start=1)))
    def season(m):
        if m in (12, 1, 2): return "Winter"
        if m in (3, 4, 5): return "Summer"
        if m in (6, 7, 8, 9): return "Monsoon"
        return "Post-monsoon"
    data["Season"] = data["Month"].map(season)
    report = {
        "input_rows": int(before),
        "duplicates_removed": int(duplicates_removed),
        "rows_after_cleaning": int(len(data)),
        "cities": int(data["City"].nunique()),
        "date_start": str(data["Date"].min().date()) if len(data) else None,
        "date_end": str(data["Date"].max().date()) if len(data) else None,
        "missing_aqi_bucket_rows": int(data["AQI_Bucket"].isna().sum()),
        "pollutant_features": POLLUTANT_FEATURES,
    }
    return data, report


def _save_fig(fig, path: Path):
    fig.tight_layout()
    fig.savefig(path, dpi=160, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def make_eda_charts(data: pd.DataFrame, out_dir: Path) -> dict:
    out_dir.mkdir(parents=True, exist_ok=True)
    charts = {}
    # AQI values for EDA remain available after dropping rows with missing AQI.
    city_avg = data.groupby("City", as_index=False)["AQI"].mean().sort_values("AQI", ascending=False)
    month_avg = data.groupby("Month", as_index=False)["AQI"].mean().sort_values("Month")
    year_avg = data.groupby("Year", as_index=False)["AQI"].mean().sort_values("Year")
    bucket_counts = data["AQI_Bucket"].dropna().value_counts().reindex(AQI_BUCKET_ORDER, fill_value=0)
    fig, axes = plt.subplots(2, 2, figsize=(12, 8))
    top = city_avg.head(10).sort_values("AQI", ascending=True)
    axes[0,0].barh(top["City"], top["AQI"])
    axes[0,0].set_title("10 cities with highest average AQI")
    axes[0,0].set_xlabel("Average AQI (higher = worse)")
    axes[0,1].plot(month_avg["Month"], month_avg["AQI"], marker="o")
    axes[0,1].set_xticks(range(1,13), MONTH_NAMES)
    axes[0,1].set_title("Average AQI by month")
    axes[0,1].set_ylabel("Average AQI")
    axes[1,0].plot(year_avg["Year"], year_avg["AQI"], marker="o")
    axes[1,0].set_title("Average AQI by year")
    axes[1,0].set_ylabel("Average AQI")
    axes[1,0].tick_params(axis="x", rotation=30)
    axes[1,1].bar(bucket_counts.index, bucket_counts.values)
    axes[1,1].set_title("Records by AQI category")
    axes[1,1].set_ylabel("Number of days")
    axes[1,1].tick_params(axis="x", rotation=35)
    charts["eda"] = out_dir / "eda.png"
    _save_fig(fig, charts["eda"])

    # Correlation chart: include AQI and numeric pollutants; use pairwise complete values.
    corr_cols = [c for c in POLLUTANT_FEATURES + ["AQI"] if c in data.columns]
    corr = data[corr_cols].corr(numeric_only=True)
    fig, ax = plt.subplots(figsize=(10, 8))
    image = ax.imshow(corr, vmin=-1, vmax=1, cmap="coolwarm", aspect="auto")
    ax.set_xticks(range(len(corr.columns)), corr.columns, rotation=45, ha="right")
    ax.set_yticks(range(len(corr.index)), corr.index)
    for i in range(len(corr.index)):
        for j in range(len(corr.columns)):
            val = corr.iloc[i,j]
            if pd.notna(val): ax.text(j, i, f"{val:.2f}", ha="center", va="center", fontsize=7)
    ax.set_title("Correlation between pollutant readings and AQI")
    fig.colorbar(image, ax=ax, shrink=0.8, label="Pearson correlation")
    charts["correlation"] = out_dir / "correlation.png"
    _save_fig(fig, charts["correlation"])

    # seasonal summary
    season_avg = data.groupby("Season", as_index=False)["AQI"].mean()
    season_avg["Season"] = pd.Categorical(season_avg["Season"], categories=SEASON_ORDER, ordered=True)
    season_avg = season_avg.sort_values("Season")
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.bar(season_avg["Season"].astype(str), season_avg["AQI"])
    ax.set_title("Average AQI by season")
    ax.set_ylabel("Average AQI")
    charts["season"] = out_dir / "seasonal_aqi.png"
    _save_fig(fig, charts["season"])
    return {k: str(v) for k,v in charts.items()}, city_avg, month_avg, year_avg, bucket_counts, corr, season_avg


def run_analysis(df: pd.DataFrame, out_dir: str | Path, save_models: bool = True) -> dict:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    data, cleaning = clean_data(df)
    if len(data) < 30:
        raise ValueError("At least 30 usable rows are needed to run the demo models.")
    charts, city_avg, month_avg, year_avg, bucket_counts, corr, season_avg = make_eda_charts(data, out_dir)
    feature_cols = POLLUTANT_FEATURES
    # numeric target for regression, split once for fair model comparison
    X = data[feature_cols]
    y = data["AQI"].astype(float)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.20, random_state=42)
    reg_estimators = {
        "Linear Regression": LinearRegression(),
        "Decision Tree": DecisionTreeRegressor(random_state=42, min_samples_leaf=3),
        "Random Forest": RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1, min_samples_leaf=2),
    }
    fitted = {}
    metrics_rows=[]
    reg_preds={}
    for name, estimator in reg_estimators.items():
        pipe = Pipeline([("imputer", SimpleImputer(strategy="median", keep_empty_features=True)), ("model", estimator)])
        pipe.fit(X_train, y_train)
        pred = pipe.predict(X_test)
        fitted[name] = pipe
        reg_preds[name] = pred
        metrics_rows.append({"Model":name,"R2":float(r2_score(y_test,pred)),"RMSE":float(np.sqrt(mean_squared_error(y_test,pred))),"MAE":float(mean_absolute_error(y_test,pred))})
    reg_metrics = pd.DataFrame(metrics_rows).sort_values("RMSE")
    best_reg_name = str(reg_metrics.iloc[0]["Model"])
    best_reg = fitted[best_reg_name]
    best_pred = reg_preds[best_reg_name]

    fig, ax = plt.subplots(figsize=(7, 6))
    ax.scatter(y_test, best_pred, alpha=0.55, s=18)
    lo = min(float(y_test.min()), float(np.min(best_pred)))
    hi = max(float(y_test.max()), float(np.max(best_pred)))
    ax.plot([lo,hi],[lo,hi], linestyle="--")
    ax.set_xlabel("Actual AQI")
    ax.set_ylabel("Predicted AQI")
    ax.set_title(f"Actual vs predicted AQI ({best_reg_name})")
    charts["actual_vs_predicted"] = str(out_dir / "actual_vs_predicted.png")
    _save_fig(fig, Path(charts["actual_vs_predicted"]))

    # Feature importances from best RF model; if another regressor wins on this dataset,
    # the plot uses the Random Forest model so the chart remains interpretable.
    forest = fitted["Random Forest"].named_steps["model"]
    imp = pd.DataFrame({"Feature":feature_cols,"Importance":forest.feature_importances_}).sort_values("Importance", ascending=False)
    fig, ax = plt.subplots(figsize=(8, 5.5))
    view=imp.sort_values("Importance", ascending=True)
    ax.barh(view["Feature"],view["Importance"])
    ax.set_xlabel("Feature importance")
    ax.set_title("Random Forest feature importance")
    charts["feature_importance"] = str(out_dir / "feature_importance.png")
    _save_fig(fig, Path(charts["feature_importance"]))

    # Classification uses only rows with a recorded AQI_Bucket label.
    cls_data = data[data["AQI_Bucket"].notna()].copy()
    cls_data = cls_data[cls_data["AQI_Bucket"].isin(AQI_BUCKET_ORDER)]
    cls_summary = {"accuracy": None, "report": {}, "labels": [], "confusion_matrix": [], "n_rows": int(len(cls_data))}
    cls_model = None
    if len(cls_data) >= 30 and cls_data["AQI_Bucket"].nunique() >= 2:
        Xc = cls_data[feature_cols]
        yc = cls_data["AQI_Bucket"].astype(str)
        stratify = yc if yc.value_counts().min() >= 2 else None
        Xc_train, Xc_test, yc_train, yc_test = train_test_split(Xc, yc, test_size=0.20, random_state=42, stratify=stratify)
        cls_model = Pipeline([("imputer", SimpleImputer(strategy="median", keep_empty_features=True)), ("model", RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1))])
        cls_model.fit(Xc_train, yc_train)
        yc_pred = cls_model.predict(Xc_test)
        labels = [lab for lab in AQI_BUCKET_ORDER if lab in set(yc_test) | set(yc_pred)]
        report = classification_report(yc_test, yc_pred, labels=labels, output_dict=True, zero_division=0)
        cm = confusion_matrix(yc_test, yc_pred, labels=labels)
        cls_summary = {"accuracy":float(accuracy_score(yc_test,yc_pred)),"report":report,"labels":labels,"confusion_matrix":cm.tolist(),"n_rows":int(len(cls_data))}
        fig, ax = plt.subplots(figsize=(8, 6.5))
        disp=ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=labels)
        disp.plot(ax=ax, cmap="Blues", values_format="d", xticks_rotation=35, colorbar=False)
        ax.set_title("Random Forest classification confusion matrix")
        charts["confusion_matrix"] = str(out_dir / "confusion_matrix.png")
        _save_fig(fig, Path(charts["confusion_matrix"]))
    else:
        charts["confusion_matrix"] = None

    city_top3 = city_avg.head(3).to_dict(orient="records")
    strongest = corr["AQI"].drop(labels=["AQI"], errors="ignore").abs().sort_values(ascending=False).head(3)
    max_corr = corr["AQI"].drop(labels=["AQI"], errors="ignore").sort_values(ascending=False).head(1)
    min_corr = corr["AQI"].drop(labels=["AQI"], errors="ignore").sort_values(ascending=True).head(1)
    summary = {
        "cleaning": cleaning,
        "regression_metrics": reg_metrics.to_dict(orient="records"),
        "best_regression_model": best_reg_name,
        "classification": cls_summary,
        "top_cities_by_aqi": city_top3,
        "city_averages": city_avg.to_dict(orient="records"),
        "monthly_averages": month_avg.to_dict(orient="records"),
        "yearly_averages": year_avg.to_dict(orient="records"),
        "seasonal_averages": [{"Season":str(r["Season"]),"AQI":float(r["AQI"])} for _,r in season_avg.iterrows()],
        "bucket_counts": {str(k):int(v) for k,v in bucket_counts.items()},
        "correlations_with_aqi": {str(k):float(v) for k,v in corr["AQI"].drop(labels=["AQI"],errors="ignore").items() if pd.notna(v)},
        "strongest_abs_correlations": [{"feature":str(k),"correlation":float(corr.loc[k,"AQI"])} for k in strongest.index],
        "highest_positive_correlation": {"feature":str(max_corr.index[0]),"correlation":float(max_corr.iloc[0])} if len(max_corr) else None,
        "most_negative_correlation": {"feature":str(min_corr.index[0]),"correlation":float(min_corr.iloc[0])} if len(min_corr) else None,
        "charts": charts,
        "source_note": "Synthetic demonstration data only" if "demo_synthetic" in str(out_dir).lower() else "Results depend on the selected CSV dataset",
    }
    if save_models:
        model_dir = out_dir / "models"
        model_dir.mkdir(parents=True, exist_ok=True)
        for name, model in fitted.items():
            filename = name.lower().replace(" ", "_") + ".joblib"
            joblib.dump(model, model_dir / filename)
        if cls_model is not None:
            joblib.dump(cls_model, model_dir / "random_forest_classifier.joblib")
        summary["model_dir"] = str(model_dir)
    data.to_csv(out_dir / "cleaned_data.csv", index=False)
    reg_metrics.to_csv(out_dir / "regression_metrics.csv", index=False)
    if cls_summary["report"]:
        pd.DataFrame(cls_summary["report"]).T.to_csv(out_dir / "classification_report.csv")
    with open(out_dir / "results_summary.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
    return {"cleaned":data,"summary":summary,"regression_metrics":reg_metrics,"regression_models":fitted,"regression_test_actual":y_test,"regression_test_predictions":best_pred,"feature_importance":imp,"classification_model":cls_model}
