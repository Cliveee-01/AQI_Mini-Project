# India Air Quality (AQI) Analysis and Prediction

**Intelligent Data Systems 1 Lab — Experiment 10: Mini Project**

A beginner-friendly Python + Streamlit + scikit-learn project that explores Indian city-day air-quality records and predicts AQI value/category from pollutant readings.

## Important dataset note

The project includes `data/city_day_demo_synthetic.csv` so the app opens and the workflow can be tested immediately. **This is synthetic demonstration data, not official air-quality observations. Do not submit its city rankings, trends, correlations, or model scores as real-world findings.**

For final results, download the original dataset and place its `city_day.csv` file here:

- Kaggle: https://www.kaggle.com/datasets/rohanrao/air-quality-data-in-india
- Expected file: `data/city_day.csv`

When `data/city_day.csv` exists, the training script and app automatically prefer it over the demo CSV. Alternatively, upload your official CSV with the app's sidebar file uploader.

## Features

- CSV data cleaning and duplicate removal
- Average AQI by city, month, year, and season
- AQI category distribution and pollutant-correlation heatmap
- Linear Regression, Decision Tree Regressor, Random Forest Regressor comparison
- Random Forest AQI category classifier
- R², RMSE, MAE, accuracy, per-category precision/recall/F1, confusion matrix
- Feature-importance and actual-vs-predicted charts
- Interactive Streamlit dashboard with a prediction form
- Downloadable cleaned data and metrics

## Folder structure

```text
India_Air_Quality_Mini_Project/
├── app.py
├── AQI_Analysis.ipynb
├── aqi_pipeline.py
├── train_models.py
├── generate_report.py
├── run_project.bat
├── requirements.txt
├── README.md
├── data/
│   ├── city_day_demo_synthetic.csv
│   ├── DATASET_NOTICE.txt
│   └── city_day.csv                 # add the official Kaggle file here
├── outputs/                         # generated charts, metrics and cleaned CSV
└── reports/
    └── Mini_Project_Report.docx
```

## Run on Windows (PowerShell)

1. Install Python 3.10 or newer from https://www.python.org/downloads/ and tick **Add Python to PATH**.
2. Open PowerShell in the project folder.
3. Create and activate an environment:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
```

4. Install packages:

```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

5. Train and generate charts/metrics:

```powershell
python train_models.py
```

6. Start the web app:

```powershell
streamlit run app.py
```

Streamlit opens the local dashboard in your browser. After dependencies are installed, you can also double-click `run_project.bat` to retrain, regenerate the report, and launch the dashboard.

### Optional Jupyter Notebook

Open `AQI_Analysis.ipynb` from the project folder after installing the dependencies. It walks through the same cleaning, EDA, regression and classification pipeline step by step.

## Output files

After `python train_models.py`, the `outputs/` directory contains:

- `results_summary.json` — machine-readable results and dataset details
- `regression_metrics.csv` — model comparison table
- `classification_report.csv` — precision/recall/F1 by category, when available
- `cleaned_data.csv` — cleaned data with date features
- `eda.png`, `correlation.png`, `seasonal_aqi.png`
- `actual_vs_predicted.png`, `feature_importance.png`, `confusion_matrix.png`
- `models/` — fitted model pipelines for the selected dataset (inside `outputs/models/`)

Use the values in `outputs/results_summary.json` and `outputs/regression_metrics.csv` to update the bracketed results in the report. The supplied report clearly labels demo results. For official results, save the Kaggle file as `data/city_day.csv`, run `python train_models.py`, then run `python generate_report.py` to regenerate the report with the real-data results.

## AQI modelling notes

- Regression predicts numeric AQI using pollutant readings.
- Classification predicts the recorded `AQI_Bucket` from pollutant readings.
- `AQI_Bucket` is never used as a feature in the regression model, and `AQI` is never used as a feature in the classification model.
- Missing pollutant values are imputed with the training-split median through a scikit-learn pipeline to avoid using test-set information during imputation.
- The classification task can score highly because AQI categories are derived from pollutant readings. A random 80/20 split evaluates interpolation within the same historical dataset, not reliable future forecasting.
- AQI-range mapping for the numeric prediction is an educational interpretation and should not be treated as an official CPCB live AQI.

## AQI category bands

For a simple interpretation of numeric predictions, the app uses these familiar bands: Good (0–50), Satisfactory (51–100), Moderate (101–200), Poor (201–300), Very Poor (301–400), and Severe (above 400). The classifier predicts the category label in the dataset.

## References

1. Rohan Rao, *Air Quality Data in India*, Kaggle: https://www.kaggle.com/datasets/rohanrao/air-quality-data-in-india
2. Central Pollution Control Board (CPCB), National Air Quality Index information: https://cpcb.nic.in/
3. scikit-learn documentation: https://scikit-learn.org/stable/
4. pandas documentation: https://pandas.pydata.org/docs/
5. Streamlit documentation: https://docs.streamlit.io/

## Frontend dashboard (AeroIQ)

The Streamlit interface has been designed as a polished, responsive dashboard with a dark sidebar, AQI colour system, KPI cards and five sections:

- **Overview:** daily-record and city metrics, average AQI, seasonal/monthly trends, city rankings and AQI-category distribution.
- **City & seasonal trends:** compare several cities, inspect yearly patterns and see pollutant correlations.
- **Model lab:** regression metric comparison, actual-vs-predicted view, feature importance, classifier report and confusion matrix.
- **Predict AQI:** enter pollutant readings and receive a numerical estimate plus an AQI category.
- **Data & method:** review cleaning counts and methodology, preview the cleaned records, and download CSV/JSON outputs.

Launch it using `streamlit run app.py`. See `FRONTEND_GUIDE.md` for a quick guide to the UI.
